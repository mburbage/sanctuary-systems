<?php
include_once 'shortcodes/shortcodes.php';
include_once 'qode-custom-post-types.php';
include_once 'qode-like.php';
include_once 'qode-seo.php';
include_once 'widgets/load.php';
include_once 'reviews/load.php';
include_once 'core-dashboard/load.php';