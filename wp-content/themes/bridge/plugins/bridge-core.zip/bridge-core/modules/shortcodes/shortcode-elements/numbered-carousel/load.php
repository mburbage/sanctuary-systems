<?php

include_once BRIDGE_CORE_SHORTCODES_PATH . '/numbered-carousel/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH . '/numbered-carousel/numbered-carousel.php';