<div class="qode-course-content">
	<?php the_content(); ?>
</div>