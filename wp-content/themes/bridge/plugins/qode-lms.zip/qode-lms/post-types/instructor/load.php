<?php

include_once QODE_LMS_CPT_PATH . '/instructor/instructor-register.php';
include_once QODE_LMS_CPT_PATH . '/instructor/helper-functions.php';
include_once QODE_LMS_CPT_PATH . '/instructor/shortcodes/shortcodes-functions.php';