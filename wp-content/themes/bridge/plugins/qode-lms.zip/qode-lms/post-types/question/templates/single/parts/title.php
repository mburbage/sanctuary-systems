<h5 class="qode-question-single-title">
	<?php echo get_the_title( $question_id ); ?>
</h5>