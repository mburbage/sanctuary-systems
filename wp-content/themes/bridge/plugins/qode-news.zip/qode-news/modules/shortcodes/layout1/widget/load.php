<?php

include_once QODE_NEWS_SHORTCODES_PATH.'/layout1/widget/functions.php';
include_once QODE_NEWS_SHORTCODES_PATH.'/layout1/widget/layout1.php';